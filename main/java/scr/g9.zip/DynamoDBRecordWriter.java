import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.mapreduce.RecordWriter;
import org.apache.hadoop.mapreduce.TaskAttemptContext;

import com.amazonaws.auth.ClasspathPropertiesFileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.*;
import com.amazonaws.services.dynamodbv2.model.*;

public class DynamoDBRecordWriter<K, V> extends RecordWriter<K, V> {

	static AmazonDynamoDBClient dynamoDB;

	private String tableName;

	public DynamoDBRecordWriter() {

		dynamoDB = new AmazonDynamoDBClient(new ClasspathPropertiesFileCredentialsProvider());
		Region usWest2 = Region.getRegion(Regions.EU_WEST_1);
		dynamoDB.setRegion(usWest2);
	};


	@Override
	public void close(TaskAttemptContext context) throws IOException, InterruptedException {

		if (dynamoDB != null)
			dynamoDB.shutdown();

	}

	public AmazonDynamoDBClient getClient() {
		return dynamoDB;
	}

	public String getTableName() {
		return tableName;
	}


	@Override
	public void write(K key, V value) throws IOException, InterruptedException {

		Map<String, AttributeValue> item;
		
		if (keyIsPhone(key.toString())) {
		
			item = newPhoneItem(key.toString(), value.toString().split(",")[0],
								Integer.parseInt(value.toString().split(",")[1]), value.toString().split(",")[2]);
		
		} else {
			
			item = cellItem(key.toString(), value.toString().split(",")[0],
								value.toString().split(",")[1], value.toString().split(",")[2]);

		}

		PutItemRequest putItemRequest = new PutItemRequest(tableName, item);
        PutItemResult putItemResult = dynamoDB.putItem(putItemRequest);
        System.out.println("Result: " + putItemResult);


	}
	
	private boolean keyIsPhone(String string) {  
		
		try {  	
			Double.parseDouble(string);  
		
		} catch(NumberFormatException nfe) {  
			
			return false;  
		}
		
		return true;  
	}
	
	private static Map<String, AttributeValue> newPhoneItem(String phoneNumber, String date, int minutesOnNet, String trace) {
		Map<String, AttributeValue> item = new HashMap<String, AttributeValue>();
		item.put("phonenumber", new AttributeValue(phoneNumber));
		item.put("date", new AttributeValue(date));
		item.put("minutesonnet", new AttributeValue().withN(Integer.toString(minutesOnNet)));
		item.put("trace", new AttributeValue().withSS(trace.split(";")));

		return item;
	}

	private static Map<String, AttributeValue> cellItem(String cellID, String date, String hour, String phones) {
		Map<String, AttributeValue> item = new HashMap<String, AttributeValue>();
		item.put("cellid", new AttributeValue(cellID));
		item.put("date", new AttributeValue(date));
		item.put("hour", new AttributeValue(hour));
		item.put("phones", new AttributeValue().withSS(phones.split(";")));

		return item;
	}

}